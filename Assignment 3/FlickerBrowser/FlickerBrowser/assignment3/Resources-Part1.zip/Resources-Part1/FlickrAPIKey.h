//
//  FlickrAPIKey.h
//

//  Get your key http://www.flickr.com/services/api/misc.api_keys.html
//  Will not fetch without it

#define FlickrAPIKey @""

